Open the numbered .scad files in order. Each is complete and standalone.
Units: mm. Preview (F5), Render (F6), then export STL.
Steps 9 and 10 make the same finished stand; step 10 replaces repeated code with loops.
Intermediate models are teaching stages, not parts to print.
The stand is a prototype: test screw fit and real PCB clearance before use.
